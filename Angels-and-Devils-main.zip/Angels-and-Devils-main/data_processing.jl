@everywhere using Serialization
@everywhere using DataFrames
@everywhere using CSV

# using Random: shuffle
# using ProgressMeter

@everywhere include("moral_games.jl")
@everywhere include("2p_games.jl")

# ordered_combos = sort(sort(all_morality_combinations, by=p->length(p[2])), by=p->length(p[1]))
# shuffled_combos = shuffle(all_morality_combinations)
@everywhere ordered_combos = all_morality_pairs

@everywhere dir = "data/1m"
@everywhere files = sort(filter(f->endswith(f,".jls"), readdir(dir)))

# for morality_combo in shuffled_combos
@sync @distributed for morality_combo in ordered_combos
    rescale_factor = 1000000
    base_game_actions = 2
    
    p1_actions = length(morality_combo[1]) * base_game_actions
    p2_actions = length(morality_combo[2]) * base_game_actions
    column_names = ["file", "type", "u1_psychic", "u1_material", "u2_psychic", "u2_material"]
    column_types = [String[], String[], Float64[], Float64[], Float64[], Float64[]]
    # column_names = ["moralities", "file", "type", "u1_psychic", "u1_material", "u2_psychic", "u2_material"]
    # column_types = [String[], String[], String[], Float64[], Float64[], Float64[], Float64[]]
    # append!(column_names, ["pr_p1a"*string(a) for a in 1:p1_actions])
    # append!(column_names, ["pr_p2a"*string(a) for a in 1:p2_actions])
    # append!(column_types, [Float64[] for a in 1:p1_actions])
    # append!(column_types, [Float64[] for a in 1:p2_actions])
    eq_data = DataFrame((n=>t for (n,t) in zip(column_names, column_types))...)

    combo_name = join(map(string,morality_combo[1])) * "_" * join(map(string,morality_combo[2]))
    short_name = join(string(m)[1] for m in morality_combo[1]) * "_" * join(string(m)[1] for m in morality_combo[2])
    csv_filename = dir*"/"*short_name*".csv"

    if isfile(csv_filename)
        continue
    else
        touch(csv_filename)
    end

    for file in files
        try
            game_data = deserialize(joinpath(dir,file))
            for (eq,material,psychic) in zip(game_data["equilibria"][combo_name], game_data["payoffs"][combo_name*"_material"], game_data["payoffs"][combo_name*"_psychic"])
                if is_pure(eq)
                    type = "pure"
                else
                    type = "mixed"
                end
                # push!(eq_data, [short_name, file, type, (psychic./rescale_factor)..., (material./rescale_factor)..., eq[1]..., eq[2]...])
                push!(eq_data, [file, type, (psychic./rescale_factor)..., (material./rescale_factor)...,])
            end
        catch e
            println("Error reading file "*file)
            continue
        end
    end
    CSV.write(csv_filename, eq_data)
end

