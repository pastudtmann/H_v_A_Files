#=
This provides an interface for the command-line tool lrsnash.
Unfortunately, that tool doesn't play nice with Julia multithreading.
Luckily, it turns out that GameTheory.jl already has lrsnash bindings,
which means this interface should be entirely unnecessary.
=#

using Suppressor

function write_lrs_game(game, filename)
    if ndims(game) == 2
        write_lrs_sym_game(game, filename)
    elseif ndims(game) == 3
        write_lrs_asym_game(game, filename)
    else
        error("2-player game matrix must be 2D (symmetric) or 3D (asymmetric)")
    end
end

function write_lrs_sym_game(sym_game, filename)
    num_actions = size(sym_game,1)
    open(filename, "w") do f
        write(f, string(num_actions) * " " * string(num_actions) * "\n\n")
        write(f, replace(string(sym_game)[2:end-1], "; "=>"\n"))
        write(f, "\n\n")
        write(f, replace(string(sym_game')[2:end-1], "; "=>"\n"))
        write(f, "\n")
    end
end

function write_lrs_game(asym_game, filename)
    open(filename, "w") do f
        write(f, string(size(asym_game,1)) * " " * string(size(asym_game,2)) * "\n\n")
        write(f, replace(string(asym_game[:,:,1])[2:end-1], "; "=>"\n"))
        write(f, "\n\n")
        write(f, replace(string(asym_game[:,:,2])[2:end-1], "; "=>"\n"))
        write(f, "\n")
    end
end


function solve_with_lrs(game, game_filename="", eq_filename=""; remove=false)
    if game_filename == ""
        game_filename = string(size(game,1)) * "x" * string(size(game,2)) * ".lrs"
    end
    if eq_filename == ""
        eq_filename = string(size(game,1)) * "x" * string(size(game,2)) * ".eq"
    end
    write_lrs_game(game, game_filename)
    @suppress_out run(`lrsnash $game_filename -o $eq_filename`)
    equilibria = read_lrs_equilibria(eq_filename)
    if remove
        rm(game_filename)
        rm(eq_filename)
    end
    return equilibria
end

function read_lrs_equilibria(eq_filename, T::Type=Float64)
    lines = readlines(eq_filename)
    body_lines = lines[1:end-6]
    empty_line_indices = findall( .==(""), body_lines)
    lines_per_eq = empty_line_indices[2:end] - empty_line_indices[1:end-1] .- 1
    eq_lines = body_lines[body_lines .!= ""]
    
    pure_equilibria = Vector{Matrix{T}}()
    mixed_equilibria = Vector{Matrix{T}}()
    continuum_equilibria = Vector{Matrix{T}}()

    l = 1
    for num_lines in lines_per_eq
        if num_lines > 2            
            # add to continuum
            p1_strats = []
            p2_strats = []
            equilibrium = Dict(1=>[], 2=>[])
            for i=0:num_lines-1
                player,strat = lrs_line_to_mix(eq_lines[l+i])
                if player == 1
                    push!(p1_strats, strat)
                else
                    push!(p2_strats, strat)
                end
            end
            for (s1,s2) in Iterators.product(p1_strats, p2_strats)
                equilibrium = zeros(T, 2, max(length(s1), length(s2)))
                equilibrium[1,:] = s1
                equilibrium[2,:] = s1
                push!(continuum_equilibria, equilibrium)
            end
        else
            # add to pure or mixed
            p1,s1 = lrs_line_to_mix(eq_lines[l])   # we don't know a priori which player's strategy will come first
            p2,s2 = lrs_line_to_mix(eq_lines[l+1])
            equilibrium = zeros(T, 2, max(length(s1), length(s2)))
            equilibrium[p1,1:length(s1)] = s1
            equilibrium[p2,1:length(s2)] = s2
            if is_pure(equilibrium)
                push!(pure_equilibria, equilibrium)
            else
                push!(mixed_equilibria, equilibrium)
            end
        end
        l += num_lines
    end
    return (pure_equilibria, mixed_equilibria, continuum_equilibria)
end

function string_to_rational(s)
    if occursin("/", s)
        (numerator, denominator) = split(s, "/")
        return parse(Int128, numerator) // parse(Int128, denominator)
    else
        return parse(Int128, s) // 1
    end
end

function lrs_line_to_mix(line)
    player = parse(Int64, split(line)[1])
    EV = string_to_rational(split(line)[end])
    mix = [string_to_rational(s) for s in split(line)[2:end-1]]
    @assert (sum(mix) == 1) "mix doesn't sum to 1"
    return player,mix,EV
end

function is_pure(equilibrium::Matrix)
    return all(isapprox.(maximum(equilibrium, dims=2), 1))
end

function is_symmetric(equilibrium::Matrix)
    return all(equilibrium[1,:] .== equilibrium[2,:])
end