using Pkg
Pkg.activate(".")
using JLD

function main()
    overall_pure = 0
    overall_mixed = 0
    overall_continua = 0
    dir = "data_no_duplicates"
    subdirectories = filter(d->isdir(joinpath(dir,d)), readdir(dir))
    for (i,subdir) in enumerate(subdirectories)
        println(i, ": ", subdir)
        subdir_path = joinpath(dir,subdir)
        this_dir_pure = 0
        this_dir_mixed = 0
        this_dir_continua = 0
        jld_files = filter(s->endswith(s,".jld"), readdir(subdir_path))
        for data_file in jld_files
            file_path = joinpath(subdir_path, data_file)
            data = load(file_path)
            if length(data["pure"]) > 0
                this_dir_pure += 1
            end
            if length(data["mixed"]) > 0
                this_dir_mixed += 1
            end
            if length(data["continuum"]) > 0
                this_dir_continua += 1
            end
        end
        println("\tpure: ", this_dir_pure / length(jld_files))
        println("\tmixed: ", this_dir_mixed / length(jld_files))
        println("\tcontinua: ", this_dir_continua / length(jld_files))
        overall_pure += this_dir_pure
        overall_mixed += this_dir_mixed
        overall_continua += this_dir_continua
    end
    println("overall pure: ", overall_pure / length(subdirectories)) # this assumes that all subdirectories have the same #files
    println("overall mixed: ", overall_mixed / length(subdirectories))
    println("overall continua: ", overall_continua / length(subdirectories))
end

main()