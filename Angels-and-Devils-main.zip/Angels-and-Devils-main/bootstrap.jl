
# using Distributed
using DataFrames
using CSV
using Statistics
using Bootstrap

dir = "data/1m/utilities"
files = sort(filter(f->endswith(f,".csv"), readdir(dir)))
percentiles =  [ .1:.1:.9 ; .91:.01:.99 ; .991:.001:.999 ; .9991:.0001:.9999 ]

# n_resamples = 1_000_000
n_resamples = 10

for file in files
    moralities = splitext(file)[1]
    in_df = DataFrame(CSV.File(joinpath(dir, file)))
    by_game = groupby(in_df, :file)
    payoffs = combine(by_game, :u1_psychic => mean, :u1_material => mean, :u2_psychic => mean, :u2_material => mean)
    arr = Array(payoffs[:,Not(:file)])
    bootstrapped = bootstrap(a->mean(a,dims=1), arr, BasicSampling(n_resamples))
    out_cols = [["quantile"]; [plr * pay * bnd for bnd in ["lb","ub"] for plr in ["u1_","u2_"] for pay in ["psychic_","material_"]]]
    out_df = DataFrame((col=>Float64[] for col in out_cols)...)
    for pct in percentiles
        cis = confint(bootstrapped, PercentileConfInt(pct))
        lbs = [ci[2] for ci in cis]
        ubs = [ci[3] for ci in cis]
        row = [[pct]; lbs; ubs]
        push!(out_df, row)
    end
    csv_filename = moralities * "_bootstrap.csv"
    CSV.write(joinpath(dir, csv_filename), out_df)
    break
end