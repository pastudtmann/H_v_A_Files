using LinearAlgebra
using Random
using Printf

function random_game(num_actions=2, min_payoff=-1000000, max_payoff=1000000; symmetric=true, reject_duplicates=true, payoff_increment=10)
    min_payoff ÷= payoff_increment
    max_payoff ÷= payoff_increment
    dims = symmetric ? [num_actions,num_actions] : [num_actions,num_actions,2]
    g = rand(min_payoff:max_payoff, dims...)
    while reject_duplicates && length(unique(g)) != length(g)
        g = rand(min_payoff:max_payoff, dims...)
    end
    return g .* payoff_increment
end

function perturb_game(game, increment=1)
    num_entries = length(game)
    perturbation = (reshape(shuffle(0:num_entries-1), size(game)) .* increment) .- (num_entries ÷ 2)
    return game .+ perturbation
end

function print_game(game)
    if ndims(game) == 2
        # Add the second player's payoffs to a symmetric representation
        g = zeros(eltype(game), size(game)..., 2)
        g[:,:,1] = game
        g[:,:,2] = game'
        game = g
    end
    digits = Int64(ceil(log(10,maximum(game))))
    if minimum(game) < 0
        digits = max(digits, Int64(ceil(log(10,abs(minimum(game)))))  + 1)
    end
    A1 = size(game, 1)
    A2 = size(game, 2)
    println(repeat("-", (2*digits+1)*A2 + 3*(A2-1) + 4))
    for a1 = 1:A1
        print("| ")
        for a2 = 1:A2
            print(lpad(game[a1,a2,1],digits," "), ",", rpad(game[a1,a2,2],digits," "), " | ")
        end
        println()
        println(repeat("-", (2*digits+1)*A2 + 3*(A2-1) + 4))
    end
end

function format_strategy(strat, precision=3)
    format = "%." * string(precision) * "f"
    repr = join(Printf.format.(Ref(Printf.Format(format)), strat), ", ")
    return "< " * repr * " >"
end

function print_strategy(strat, precision=3)
    println(format_strategy(strat, precision))
end

function format_profile(prof, precision=3)
    strat_reprs = [format_strategy(strat, precision) for strat in prof]
    return "[ " * join(strat_reprs, "\n  ") * " ]"
end

function print_profile(prof, precision=3)
    println(format_profile(prof, precision))
end

function is_symmetric(equilibrium::Tuple)
    return all(equilibrium[1] .== equilibrium[2])
end

function is_pure(equilibrium::Tuple)
    return all(isapprox(maximum(strat), 1) for strat in equilibrium)
end

function includes_continuum(equilibria::Vector{<:Tuple})
    P = length(equilibria[1])
    return any(length(Set(eq[p] for eq in equilibria)) != length(equilibria) for p in 1:P)
end

function expected_payoffs(sym_game::Matrix, profile::Tuple)
    u1 = profile[1]' * sym_game * profile[2]
    u2 = profile[1]' * sym_game' * profile[2]
    return u1,u2
end

function expected_payoffs(asym_game::Array{<:Number, 3}, profile::Tuple)
    u1 = profile[1]' * asym_game[:,:,1] * profile[2]
    u2 = profile[1]' * asym_game[:,:,2] * profile[2]
    return u1,u2
end