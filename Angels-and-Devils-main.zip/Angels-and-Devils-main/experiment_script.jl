#! /usr/bin/env julia

using JSON: parsefile
using Combinatorics: combinations
using ArgParse: ArgParseSettings, @add_arg_table, parse_args

using Distributed

@everywhere using GameTheory: NormalFormGame, lrsnash
@everywhere using Serialization: serialize

s = ArgParseSettings()
@add_arg_table s begin
    "params"
        help = "JSON file with experiment parameters."
        required = true
end
parsed_args = parse_args(s)
PARAMS = parsefile(parsed_args["params"])

@everywhere include("2p_games.jl")
@everywhere include("moral_games.jl")

data_dir = PARAMS["data_directory"]
if !isdir(data_dir)
    mkdir(data_dir)
end

@everywhere function explore_moralities(base_game; prevent_ties=true)
    all_games_have_equilibria = true
    base_equilibria = lrsnash(NormalFormGame(base_game))
    if length(base_equilibria) == 0
        all_games_have_equilibria = false
    end
    games = Dict{String, Array}("base" => base_game)
    equilibria = Dict{String, Array}("base" => base_equilibria)
    payoffs = Dict{String, Array}("base" => [expected_payoffs(base_game, eq) for eq in base_equilibria])
    # for (p1_moralities, p2_moralities) in all_morality_combinations
    for (p1_moralities, p2_moralities) in all_morality_pairs
        game_name = join(map(string, p1_moralities)) * "_" * join(map(string, p2_moralities))
        moral_game = moral_extension(base_game, p1_moralities, p2_moralities; prevent_ties=prevent_ties)
        moral_equilibria = lrsnash(NormalFormGame(moral_game))
        if length(moral_equilibria) == 0
            all_games_have_equilibria = false
        end
        games[game_name] = moral_game
        equilibria[game_name] = moral_equilibria
        payoffs[game_name * "_psychic"] = [expected_payoffs(moral_game, eq) for eq in moral_equilibria]
        payoffs[game_name * "_material"] = [material_payoffs(base_game, eq) for eq in moral_equilibria]
    end
    return games, equilibria, payoffs, all_games_have_equilibria
end

@everywhere function experiment_batch(base_game_args, base_game_kwds, batch_start, batch_end, data_dir, prevent_ties, total_games)
    digits = length(string(total_games))
    for i in batch_start:batch_end
        filename = "game_"*lpad(i,digits,"0")*".jls"
        if isfile(joinpath(data_dir, filename))
            continue
        end
        num_tries = 0
        base_game = random_game(base_game_args...; base_game_kwds...)
        games, equilibria, payoffs, all_games_have_equilibria = explore_moralities(base_game; prevent_ties=prevent_ties)
        while !all_games_have_equilibria
            num_tries += 1
            error_filename = "game_"*string(i)*"_no_eq_"*str(num_tries)*".jls"
            serialize(joinpath(data_dir, error_filename), Dict("games"=>games, "equilibria"=>equilibria, "payoffs"=>payoffs))
            base_game = random_game(base_game_args...; base_game_kwds...)
            games, equilibria, payoffs, all_games_have_equilibria = explore_moralities(base_game; prevent_ties=prevent_ties)
        end
        serialize(joinpath(data_dir, filename), Dict("games"=>games, "equilibria"=>equilibria, "payoffs"=>payoffs))
        GC.gc()
    end
end    


base_game_arg_names = ["num_actions","min_payoff","max_payoff"]
base_game_kwd_names = ["payoff_increment","symmetric","reject_duplicates","payoff_increment"]
base_game_arg_vals = [PARAMS[arg] for arg in base_game_arg_names]
base_game_kwd_vals = Dict(Symbol(kwd)=>PARAMS[kwd] for kwd in base_game_kwd_names)

@sync @distributed for batch_start=1:PARAMS["games_per_batch"]:PARAMS["total_games"]
    batch_end = min(batch_start + PARAMS["games_per_batch"] - 1, PARAMS["total_games"])
    experiment_batch(base_game_arg_vals, base_game_kwd_vals, batch_start, batch_end, data_dir, PARAMS["prevent_ties"], PARAMS["total_games"])
    print("finished batch ", batch_end ÷ PARAMS["games_per_batch"])
end

# experiment_batch(base_game_arg_vals, base_game_kwd_vals, 382395, 382395, data_dir, PARAMS["prevent_ties"])