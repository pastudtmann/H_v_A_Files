using Combinatorics: powerset, with_replacement_combinations as CwR, combinations

function Nashian(sym_game)
    return sym_game
end

function Utilitarian(sym_game)
    return (sym_game .+ sym_game') .÷ 2
end

function Kantian(sym_game)
    k_game = zero(sym_game)
    k_game .= diag(sym_game)
    return k_game
end

function Empath(sym_game)
    return sym_game'
end

function Rawlsian(sym_game)
    return min.(sym_game, sym_game')
end

morality_functions = [Nashian, Utilitarian, Kantian, Empath, Rawlsian]

function nonempty_subsets(collection)
    return filter(s -> length(s) > 0, collect(powerset(collection)))
end

all_morality_combinations = collect(CwR(nonempty_subsets(morality_functions), 2))

all_morality_pairs = collect(CwR(collect(combinations(morality_functions, 2)), 2))

function moral_extension(sym_game, p1_moralities, p2_moralities; prevent_ties=false)
    num_actions = size(sym_game,1)
    extended_game = zeros(Int64, num_actions * length(p1_moralities), num_actions * length(p2_moralities), 2)
    for (i,m1) in enumerate(p1_moralities)
        for (j,m2) in enumerate(p2_moralities)
            p1_range = (i-1)*num_actions + 1 : i*num_actions
            p2_range = (j-1)*num_actions + 1 : j*num_actions
            extended_game[p1_range,p2_range,1] = m1(sym_game)
            extended_game[p1_range,p2_range,2] = m2(sym_game)'
        end
    end
    while prevent_ties && length(unique(extended_game)) != length(extended_game)
        extended_game = perturb_game(extended_game)
    end
    return extended_game
end

function base_action_probs(moral_strat::Vector, num_actions::Integer)
    num_moralities = size(moral_strat, 1) ÷ num_actions
    return dropdims(sum(reshape(moral_strat, num_actions, num_moralities), dims=2), dims=2)
end

function material_payoffs(base_game, profile::Tuple)
    p1_base_strat = base_action_probs(profile[1], size(base_game,1))
    p2_base_strat = base_action_probs(profile[2], size(base_game,2))
    u1 = p1_base_strat' * base_game * p2_base_strat
    u2 = p2_base_strat' * base_game * p1_base_strat
    return u1,u2
end